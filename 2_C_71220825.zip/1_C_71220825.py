nama = str(input("masukan nama anda: "))
mata_kuliah = str(input("masukan mata kuliah: "))
grup = str(input("masukan grup: "))
print("Haloo! " + str(nama))
print("Cassandra tergabung dalam kelas " + str(mata_kuliah))
print("Pada_grup " + str(grup))



nama = str(input("masukan nama anda: "))
mata_kuliah = str(input("masukan mata kuliah: "))
grup = str(input("masukan grup: "))
print("Haloo! " + str(nama))
print("Alaska tergabung dalam kelas " + str(mata_kuliah))
print("Pada_grup " + str(grup))

