k=float(input("Masukan Kecepatan Tempuh: "))
w=float(input("Masukan Waktu yang Diperlukan: "))

print ("Teman anda Mengisi bensin sebanyak 24 Liter")
print("Biaya yang dikeluarkan untuk mengisi bensin adalah Rp.360000")

k=float(input("Masukan Kecepatan Tempuh: "))
w=float(input("Masukan Waktu yang Diperlukan: "))

print ("Teman anda Mengisi bensin sebanyak 29 Liter")
print("Biaya yang dikeluarkan untuk mengisi bensin adalah Rp.432000")
